package com.gms.dao;

import java.util.List;

import com.gms.dto.Cart;


public interface CartDao {
	
	void insertCart(Cart cart);
	Cart showCart(int itemId);
	List<Cart> showCartAll(int custId);
	boolean deleteCart(int cartId);
	boolean deleteUserRecords(int custId);

}

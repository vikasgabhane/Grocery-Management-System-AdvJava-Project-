package com.gms.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.gms.dto.Item;

@Repository
public class ItemDaoImple implements ItemDao {
	
	@Autowired
	private HibernateTemplate hibernateTemplate;


	@Override
	public void insertItem(Item item) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.save(item);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});

		
	}

	@Override
	public void updateItem(Item item) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				
				
				session.update(item);
				
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});

		
	}

	@Override
	public void deleteItem(int itemId) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.delete(new Item(itemId));
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});

		
	}

	@Override
	public Item showItem(int itemId) {
		Item item = hibernateTemplate.execute(new HibernateCallback<Item>() {

			@Override
			public Item doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Item i = (Item)session.get(Item.class, itemId);
				tr.commit();
				session.flush();
				session.close();
				return i;
			}
			
		});
		return item;

		
	}

	@Override
	public List<Item> showAll() {
		List<Item> itemList = hibernateTemplate.execute(new HibernateCallback<List<Item>>() {

			@Override
			public List<Item> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Item");
				//q.setInteger(0, sellerId);
				List<Item> li = q.list();
				System.out.println(li); 
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
			
		});
		return itemList;

	}
	

}

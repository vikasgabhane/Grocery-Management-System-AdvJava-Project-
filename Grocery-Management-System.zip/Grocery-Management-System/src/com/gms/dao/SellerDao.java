package com.gms.dao;

import com.gms.dto.Seller;

public interface SellerDao {
	
	void insertSeller(Seller seller);
	boolean checkSeller(Seller seller);

}

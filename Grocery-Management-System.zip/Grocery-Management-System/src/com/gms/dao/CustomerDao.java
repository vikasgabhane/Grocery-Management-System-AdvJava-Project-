package com.gms.dao;

import com.gms.dto.Customer;

public interface CustomerDao {
	
	void insertCustomer(Customer customer);
	boolean checkCustomer(Customer customer);
	String findPassword(String custEmail);

}

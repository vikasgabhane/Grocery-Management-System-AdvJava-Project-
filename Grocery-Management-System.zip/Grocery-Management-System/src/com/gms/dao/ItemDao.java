package com.gms.dao;

import java.util.List;

import com.gms.dto.Item;

public interface ItemDao {
	
	void insertItem(Item item);
	void updateItem(Item item);
	void deleteItem(int itemId);
	Item showItem(int itemId);
	List<Item> showAll();

}

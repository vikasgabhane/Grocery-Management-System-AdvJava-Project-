package com.gms.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="seller")
public class Seller {
	
	@Id
	@GeneratedValue
	private int sellerId;
	@Column(unique = true)
	private String sellerName;
	private String sellerPass;
	@Column(unique = true)
	private String sellerMobile;
	@Column(unique = true)
	private String sellerEmail;
	public Seller() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getSellerId() {
		return sellerId;
	}
	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}
	public String getSellerName() {
		return sellerName;
	}
	public void setSellerName(String sellerName) {
		this.sellerName = sellerName;
	}
	public String getSellerPass() {
		return sellerPass;
	}
	public void setSellerPass(String sellerPass) {
		this.sellerPass = sellerPass;
	}
	public String getSellerMobile() {
		return sellerMobile;
	}
	public void setSellerMobile(String sellerMobile) {
		this.sellerMobile = sellerMobile;
	}
	public String getSellerEmail() {
		return sellerEmail;
	}
	public void setSellerEmail(String sellerEmail) {
		this.sellerEmail = sellerEmail;
	}
	
	
	

}

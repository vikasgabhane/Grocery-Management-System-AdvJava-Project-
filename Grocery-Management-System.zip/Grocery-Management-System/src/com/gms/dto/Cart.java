package com.gms.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="cart")
public class Cart {
	
	@Id
	@GeneratedValue
	private int cartId;
	private int itemId;
	private String itemName;
	private String catagory;
	private float price;
	private int quantity;
	private int custId;
	public Cart() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Cart(int itemId) {
		super();
		this.itemId = itemId;
	}
	
	

	public Cart(int itemId, String itemName, String catagory, float price, int quantity, int custId) {
		super();
		this.itemId = itemId;
		this.itemName = itemName;
		this.catagory = catagory;
		this.price = price;
		this.quantity = quantity;
		this.custId = custId;
	}

	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getCatagory() {
		return catagory;
	}
	public void setCatagory(String catagory) {
		this.catagory = catagory;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	

}

package com.gms.valid;

import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.gms.dto.Customer;
@Service
public class CustomerValidation implements Validator {
	
	@Override
	public boolean supports(Class<?> clazz) {
		return clazz.equals(Customer.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "custName","cnmKey", "user name required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "custPass", "passKey","password required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "custMobile","mobileKey", "Mobile No. required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "custEmail", "emailKey","EmailId required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "custAddress", "addKey","Address required");
		
		Customer customer = (Customer)target;
		if(customer.getCustPass()!=null) {
			if(customer.getCustPass().length()<3) { 
				errors.rejectValue("custPass", "passKey", "password should contain more 2 chars");
			}
		}
		
		
	}


}

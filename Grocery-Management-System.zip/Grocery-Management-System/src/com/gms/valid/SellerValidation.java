package com.gms.valid;

import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.gms.dto.Seller;


@Service
public class SellerValidation implements Validator {
	
	@Override
	public boolean supports(Class<?> clazz) {
		return clazz.equals(Seller.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "sellerName","unmKey", "user name required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "sellerPass", "passKey","password required");
		
		Seller seller = (Seller)target;
		if(seller.getSellerPass()!=null) {
			if(seller.getSellerPass().length()<3) { 
				errors.rejectValue("sellerPass", "passKey", "password should contain more 2 chars");
			}
		}
		
		
	}

}

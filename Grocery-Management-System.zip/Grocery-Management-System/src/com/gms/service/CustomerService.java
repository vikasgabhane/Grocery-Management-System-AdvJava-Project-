package com.gms.service;

import com.gms.dto.Customer;

public interface CustomerService {
	
	void addCustomer(Customer customer);
	boolean findCustomer(Customer customer);
	String forgotPassword(String custEmail);

}

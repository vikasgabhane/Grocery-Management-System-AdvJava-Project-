package com.gms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gms.dao.ItemDao;
import com.gms.dto.Item;

@Service
public class ItemServiceImple implements ItemService{
	@Autowired
	private ItemDao itemDao;

	@Override
	public void addItem(Item item) {
		
		itemDao.insertItem(item);
	}

	@Override
	public void modifyItem(Item item) {
		
		itemDao.updateItem(item);
		
	}

	@Override
	public void removeItem(int itemId) {
		itemDao.deleteItem(itemId);
		
	}

	@Override
	public Item selectItem(int itemId) {
		
		return itemDao.showItem(itemId);
	}

	@Override
	public List<Item> selectAll() {
		
		return itemDao.showAll();
	}

}

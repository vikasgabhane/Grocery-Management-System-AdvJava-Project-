package com.gms.service;

import java.util.List;

import com.gms.dto.Cart;
import com.gms.dto.Item;

public interface CartService {
	
	void addCart(Cart cart);
	Cart selectCart(int itemId);
	List<Cart> selectCartAll(int custId);
	boolean removeCart(int cartId);
	boolean removeUserRecords(int custId);
}

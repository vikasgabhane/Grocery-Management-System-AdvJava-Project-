package com.gms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gms.dao.SellerDao;
import com.gms.dto.Seller;

@Service
public class SellerServiceImple implements SellerService {
	
	@Autowired
	private SellerDao sellerDao;

	@Override
	public void addSeller(Seller seller) {
		sellerDao.insertSeller(seller);
		
	}

	@Override
	public boolean findSeller(Seller seller) {
		
		return sellerDao.checkSeller(seller);
	}
	
	
	
	

}

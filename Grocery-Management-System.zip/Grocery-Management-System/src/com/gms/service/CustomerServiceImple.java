package com.gms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gms.dao.CustomerDao;
import com.gms.dto.Customer;

@Service
public class CustomerServiceImple implements CustomerService {
	
	@Autowired
	private CustomerDao customerDao;

	@Override
	public void addCustomer(Customer customer) {

		customerDao.insertCustomer(customer);
		
	}

	@Override
	public boolean findCustomer(Customer customer) {
		
		return customerDao.checkCustomer(customer);
	}

	@Override
	public String forgotPassword(String custEmail) {
		
		return customerDao.findPassword(custEmail);
	}

}

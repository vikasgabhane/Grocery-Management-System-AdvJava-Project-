package com.gms.service;

import java.util.List;

import com.gms.dto.Item;

public interface ItemService {
	
	void addItem(Item item);
	void modifyItem(Item item);
	void removeItem(int itemId);
	Item selectItem(int itemId);
	List<Item> selectAll();

}

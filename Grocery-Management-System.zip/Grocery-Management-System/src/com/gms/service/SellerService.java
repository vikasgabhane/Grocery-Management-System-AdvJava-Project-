package com.gms.service;

import com.gms.dto.Seller;

public interface SellerService {
	
	void addSeller(Seller seller);
	boolean findSeller(Seller seller);

}

package com.gms.cntr;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.gms.dto.Cart;
import com.gms.dto.Customer;
import com.gms.dto.Item;
import com.gms.service.CartService;
import com.gms.service.ItemService;

@Controller
public class CartController {
	@Autowired
	private CartService cartService;
	@Autowired
	private ItemService itemService;
	
	@RequestMapping(value = "/addToCart.htm", method = RequestMethod.POST)
	public String addToCart(Cart cart, ModelMap map, HttpSession session) {
		
		System.out.println("hi");
		if(((Customer)session.getAttribute("customer")) == null)
			return "login_form_cust";
		
		
		System.out.println(cart.getItemId()+" "+cart.getQuantity());
		cart.setCustId(((Customer)session.getAttribute("customer")).getCustId());
		Item item = itemService.selectItem(cart.getItemId());
		cart.setPrice(item.getPrice() * cart.getQuantity());
		cart.setItemName(item.getItemName());
		cart.setCatagory(item.getCatagory());
		cartService.addCart(cart);
		
		List<Item> li = itemService.selectAll();
		map.put("itemList", li);
		return "home_cust";
	}
	
	
	
	@RequestMapping(value = "/getCart.htm")
	public String getCart(ModelMap map, HttpSession session) {
		int custId = ((Customer)session.getAttribute("customer")).getCustId();
		List<Cart> itemsList = cartService.selectCartAll(custId);
		map.put("itemsList", itemsList);
		return "cart";
	}
	
	
	@RequestMapping(value = "/delItem.htm")
	public String deleteItemFromCart(@RequestParam int cartId, ModelMap map, HttpSession session) {
		int custId = ((Customer)session.getAttribute("customer")).getCustId();
		boolean b =cartService.removeCart(cartId);
		//cartService.removeUserRecords(cartId)
		List<Cart> itemsList = cartService.selectCartAll(custId);
		map.put("itemsList", itemsList);
		return "cart";
	}


}

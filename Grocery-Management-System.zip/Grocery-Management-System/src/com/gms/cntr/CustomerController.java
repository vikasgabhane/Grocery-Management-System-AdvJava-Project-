package com.gms.cntr;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;

import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.gms.dto.Customer;
import com.gms.dto.Item;
import com.gms.service.CustomerService;
import com.gms.service.ItemService;
import com.gms.valid.CustomerValidation;

@Controller
public class CustomerController {
	
	@Autowired
	private CustomerService customerService;
	
	@Autowired
	private MailSender mailSender;
	
	@Autowired
	private CustomerValidation customerValidation;

	@Autowired
	private ItemService itemService;
	
	@RequestMapping(value="/prep_reg_cust.htm", method = RequestMethod.GET)
	public String prepRegForm(ModelMap map) {
		map.put("customer", new Customer());
		return "reg_form_cust";
	}
	
	@RequestMapping(value = "/reg_cust.htm",method = RequestMethod.POST)
	public String register(Customer customer,BindingResult result, ModelMap map)
	{
		customerValidation.validate(customer, result);
		if(result.hasErrors()) {
			return "reg_form_cust";
		}
		customerService.addCustomer(customer);;
		return "index";
	}
	
	@RequestMapping(value = "/prep_log_cust.htm",method = RequestMethod.GET)
	public String prepLogForm(ModelMap map) {
		map.put("customer", new Customer());
		return "login_form_cust";
	}
	
	@RequestMapping(value = "/login_cust.htm",method = RequestMethod.POST)
	public String login(Customer customer,BindingResult result, ModelMap map,HttpSession session) {
		//customerValidation.validate(customer, result);
		//if(result.hasErrors()) {
		//	return "login_form_cust";
		//}
		System.out.println("hello");
		boolean b = customerService.findCustomer(customer);
		if(b) {
			session.setAttribute("customer", customer);
			List<Item> li = itemService.selectAll();
			map.put("itemList", li);
			return "home_cust";
		}else {
			map.put("customer", new Customer());
			return "login_form_cust";
		}
	}
	
//	@RequestMapping(value = "/logout_cust.htm")
//	public String logout(ModelMap map, HttpSession session) {
//	map.put("customer", new Customer());
//		session.invalidate();
//		return "index";
//	}
	
	@RequestMapping(value="/prep_forgot_password.htm", method = RequestMethod.GET)
	public String prepForgotPasswordForm(ModelMap map) {
		map.put("customer", new Customer());
		return "forgot_password";
	}
	
	@RequestMapping(value = "/forgot_password.htm",method = RequestMethod.POST)
	public String forgotPassword(@RequestParam String custEmail,ModelMap map) {		
		String pass = customerService.forgotPassword(custEmail);
		String msg = "you are not registered";
		if(pass!=null) {	
			
			SimpleMailMessage message = new SimpleMailMessage();  
	        message.setFrom("cdacmumbai3@gmail.com");  
	        message.setTo(custEmail);  
	        message.setSubject("Your password");  
	        message.setText(pass);  
	        //sending message   
	        mailSender.send(message);
			msg = "check the mail for password";
		}
		map.put("msg", msg);
		return "info_cust";
	}
	
//	@RequestMapping(value = "/prep_home_cust.htm",method = RequestMethod.GET)
//	public String prepHomePage(ModelMap map) {
//		List<Item> li = itemService.selectAll();
//		map.put("itemList", li);
//		return "home_cust";
//	}
//	



}

package com.gms.cntr;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.gms.dto.Customer;
import com.gms.dto.Seller;
import com.gms.service.SellerService;
import com.gms.valid.SellerValidation;

@Controller
public class SellerController {
	
	@Autowired
	private SellerService sellerService;
	@Autowired
	private SellerValidation sellerValidation;
	
	@RequestMapping(value="/prep_reg_seller.htm", method = RequestMethod.GET)
	public String prepRegForm(ModelMap map) {
		map.put("seller", new Seller());
		return "reg_form_seller";
	}
	
	@RequestMapping(value = "/reg_seller.htm",method = RequestMethod.POST)
	public String register(Seller seller, ModelMap map)
	{
		sellerService.addSeller(seller);
		return "index";
	}
	
	@RequestMapping(value = "/prep_log_seller.htm",method = RequestMethod.GET)
	public String prepLogForm(ModelMap map) {
		map.put("seller", new Seller());
		return "login_form_seller";
	}
	
	@RequestMapping(value = "/login_seller.htm",method = RequestMethod.POST)
	public String login(Seller seller,BindingResult result ,ModelMap map,HttpSession session) {
		
		sellerValidation.validate(seller, result);
		if(result.hasErrors()) {
			return "login_form_seller";
		}
		boolean b = sellerService.findSeller(seller);
		if(b) {
			session.setAttribute("seller", seller);
			return "home_seller";
		}else {
			map.put("seller", new Seller());
			return "login_form_seller";
		}
	}
	
	@RequestMapping(value = "/logout_seller.htm")
	public String logout(ModelMap map, HttpSession session) {
		map.put("seller", new Seller());
		session.invalidate();
		return "index";
	}

}

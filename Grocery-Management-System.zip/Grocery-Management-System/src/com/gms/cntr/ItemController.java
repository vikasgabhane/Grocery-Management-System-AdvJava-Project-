package com.gms.cntr;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.gms.dto.Item;
import com.gms.dto.Seller;
import com.gms.service.ItemService;

@Controller
public class ItemController {
	
	@Autowired
	private ItemService itemService;
	
	@RequestMapping(value = "/prep_add_item_form.htm",method = RequestMethod.GET)
	public String prepItemAddForm(ModelMap map) {
		map.put("item", new Item());
		return "item_add_form";
	}
	
	@RequestMapping(value = "/item_add.htm",method = RequestMethod.POST)
	public String itemAdd(Item item,HttpSession session) {
		//int userId = ((User)session.getAttribute("user")).getUserId();
		//expense.setUserId(userId); 
		itemService.addItem(item);
		return "home_seller";
	}

	@RequestMapping(value = "/item_delete.htm",method = RequestMethod.GET)
	public String itemDelete(@RequestParam int itemId,ModelMap map,HttpSession session) {
		
		itemService.removeItem(itemId);
		
		List<Item> li = itemService.selectAll();
		map.put("itemList", li);
		return "item_list_seller";
	}

	@RequestMapping(value = "/item_update_form.htm",method = RequestMethod.GET)
	public String itemUpdateForm(@RequestParam int itemId,ModelMap map) {
		
		Item itm = itemService.selectItem(itemId);
		
		map.put("item", itm);
		
		return "item_update_form";
	}

	@RequestMapping(value = "/item_update.htm",method = RequestMethod.POST)
	public String itemUpdate(Item item,ModelMap map,HttpSession session) {
		
		//int userId = ((User)session.getAttribute("user")).getUserId();
		//expense.setUserId(userId);
		itemService.modifyItem(item);
			
		List<Item> li = itemService.selectAll();
		map.put("itemList", li);
		return "item_list_seller";
	}


	
	
	@RequestMapping(value = "/prep_item_list_seller_form.htm",method = RequestMethod.GET)
	public String allItem(ModelMap map,HttpSession session) {
		List<Item> li = itemService.selectAll();
		map.put("itemList", li);
		return "item_list_seller";
	}


}
